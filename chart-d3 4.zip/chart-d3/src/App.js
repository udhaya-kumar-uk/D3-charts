import React, { Component } from 'react';
import { scaleLinear, scaleBand } from 'd3-scale';
import XYAxis from './components/axis/xy-axis';
import './App.css';

class App extends Component {
  constructor() {
    super();
    this.state = {
      data: [
        { name: 'jhon', value: 30 },
        { name: 'doe', value: 10 },
        { name: 'michel', value: 50 },
        { name: 'curran', value: 20 },
        { name: 'tom', value: 80 },
        { name: 'jos', value: 30 },
        { name: 'glen', value: 0 },
        { name: 'jack', value: 20 },
        { name: 'kane', value: 100 },
        { name: 'david', value: 55 },
        { name: 'abraham', value: 60 },
        { name: 'josph', value: 80 },
      ],
    };
  }

  randomData = (e) => {
    e.preventDefault();
    this.setState((prevState) => {
      const data = prevState.data.map(d => ({
        name: d.name,
        value: Math.floor((Math.random() * 100) + 1)
      }));
      return { data };
    });
  };

  render() {
    const { data } = this.state;
    const parentWidth = 500;

    const margins = {
      top: 20,
      right: 20,
      bottom: 20,
      left: 40, 
    };

    const width = parentWidth - margins.left - margins.right;
    const height = 200 - margins.top - margins.bottom;

    const ticks = 5;

    const xScale = scaleBand()
      .domain(data.map(d => d.name))
      .rangeRound([0, width]).padding(0.1);

    const yScale = scaleLinear()
      .domain([0, Math.max(...data.map(d => d.value))]) 
      .range([height, 0])
      .nice();

    return (
      <div className='main-container'>
        <div>
          <h1 className='header'>D3 scatter chart Example</h1>
          <svg
            className="scatterChartSvg"
            width={width + margins.left + margins.right}
            height={height + margins.top + margins.bottom}
          >
            <g transform={`translate(${margins.left}, ${margins.top})`}>
              
              {data.map((d, i) => (
                <circle
                  key={i}
                  cx={xScale(d.name) + xScale.bandwidth() / 2}
                  cy={yScale(d.value)}
                  r={4} 
                  fill="#007bff" 
                />
              ))}
              <XYAxis {...{ xScale, yScale, height, ticks }} />
            </g>
          </svg>
          <div>
            <button onClick={this.randomData}>Update data</button>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
